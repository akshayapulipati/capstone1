import React, { useState } from "react";
import HomeNavbar from "./HomeNavbar";
import SideBar from "./SideBar";
import "./Help.css";
 
function Help() {
  const [selectedOption, setSelectedOption] = useState('Personal');
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    description: '',
    category: '',
  });
 
  function handleOptionChange(option) {
    setSelectedOption(option);
    // Show the form when 'NewRequest' is selected
    setShowForm(option === 'newrequest');
  }
 
  function handleInputChange(event) {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  }
 
  function handleSubmit(event) {
    // Prevent the default form submission behavior
    event.preventDefault();
    // Handle form submission logic here
    console.log('Form submitted:', formData);
    // You can add more logic here based on your requirements
 
    // Optionally, you can reset the form data after submission
    setFormData({
      description: '',
      category: '',
    });
  }
 
  return (
    <div className="flex flex-col h-screen">
      <HomeNavbar />
      <div className='flex flex-1'>
        <SideBar />
        <div className="flex-1 p-8">
          <h1>Help Desk</h1>
          <div className="options">
            <button onClick={() => handleOptionChange('newrequest')} className={`button-small ${selectedOption === 'newrequest' ? 'active' : ''}`}>
              NewRequest
            </button>
          </div>
         
          {/* Display the form when 'NewRequest' is selected */}
          {showForm && (
            <div>
              <form onSubmit={handleSubmit}>
               
                <table  width="30%" height="100">
                  <tbody>
                    <tr>
                      <td><label htmlFor="description">Description</label></td>
                      <td>
                        <textarea
                          name="description"
                          value={formData.description}
                          onChange={handleInputChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td><label htmlFor="category">Category</label></td>
                      <td>
                        <select
                          name="category"
                          value={formData.category}
                          onChange={handleInputChange}
                        >
                          <option value="Employee Info">Employee Info</option>
                          <option value="loan">Loan</option>
                          <option value="income tax">Income Tax</option>
                          <option value="others">Others</option>
                        </select>
                      </td>
                    </tr>
                  </tbody>
                </table>
               
                <button
                  type="submit"
                  className="w-32 px-4 py-2 mt-6 text-sm font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-blue-500 rounded-md hover:bg-blue-400 focus:outline-none focus:ring focus:ring-blue-300 focus:ring-opacity-50"
                >
                  Submit
                </button>
              </form>
            </div>
          )}
         
        </div>
      </div>
    </div>
  );
}
 
export default Help;