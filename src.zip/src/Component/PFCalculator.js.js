import React, { useState } from 'react';
import './PFCalculator.css';
import HomeNavbar from './HomeNavbar';

 
function PFCalculator() {
 
  const [basicSalary, setBasicSalary] = useState('');
  const [pfPercentage, setPFPercentage] = useState(12);
  const [employeePF, setEmployeePF] = useState(0);
  const [employerPF, setEmployerPF] = useState(0);
 
  function calculatePF() {
    const basic = parseFloat(basicSalary);
   
    const employeePFContribution = basic * (pfPercentage / 100);
    const employerPFContribution = basic * (pfPercentage / 100);
 
    setEmployeePF(employeePFContribution);
    setEmployerPF(employerPFContribution);
  }
 
  return (
    <span>
      <div><HomeNavbar/></div>
    <div className="pf-calculator-container">
     
      <h2>PF Calculator</h2>
      <div className="input-container">
        <table>
          <tbody>
            <tr>
        <td><label>Basic Salary </label></td>
             <td>
          <input
            type="number"  style={{"border":"1px solid black","borderRadius":"5px"}}
            placeholder='enter your basic salary'
            value={basicSalary}
            onChange={(e) => setBasicSalary(e.target.value)}
          />
          </td>
          </tr>
        <tr>
        <td><label>PF Percentage  </label></td>
          <td>
          <input
            type="number"  style={{"border":"1px solid black","borderRadius":"5px"}}
            placeholder='enter your PF percentage'
            value={pfPercentage}
            onChange={(e) => setPFPercentage(e.target.value)}
          />
       </td>
       </tr>
       </tbody>
       </table>
        
      </div>
      <button onClick={calculatePF}>Calculate PF</button>
      <div className="result-container">
        <h3>Results:</h3>
        <p>Employee PF Contribution   {employeePF}</p>
        <p>Employer PF Contribution   {employerPF}</p>
      </div>
    </div>
    </span>
  );
}
 
export default PFCalculator;