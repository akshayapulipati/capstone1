import React from 'react';
import { FaFacebook, FaInstagram, FaTwitter, FaLinkedin } from 'react-icons/fa';
 
class PayrollFooter extends React.Component {
    render() {
        return (
            <footer>
                <div className="footer-container">
                    <br></br><hr></hr><br></br>
                    <div style={{ display: 'flex', alignContent:'center' }}>
                        <center><div style={{ display: 'flex' }}>
                            {/* Content for the second side */}
                           <label>Contact Us:</label>
                           <a href="https://www.instagram.com/infinite_computer_solutions/" target="_blank" rel="noopener noreferrer">
                                <FaInstagram size={30}/> </a><br></br>
                            <a href="https://in.linkedin.com/company/infinite-computer-solutions" target="_blank" rel="noopener noreferrer">
                                <FaLinkedin size={30} /><br></br>
                            </a>
                            <a href="https://www.facebook.com/infinitecomputersolutions" target="_blank" rel="noopener noreferrer">
                                <FaFacebook size={30} />
                            </a><br></br>
                            <a href="https://twitter.com/Infinite_ICS" target="_blank" rel="noopener noreferrer">
                                <FaTwitter size={30} />
                            </a><br></br>
                        </div></center>
                        <div style={{ flex: 1 }}>
                            {/* Content for the first side */}
                            <center><p>&copy; {new Date().getFullYear()} Payroll Management System</p></center>
                        </div>
                    </div>
                </div><br></br>
            </footer>
        );
    }
}
 
export default PayrollFooter;