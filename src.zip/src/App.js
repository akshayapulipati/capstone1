import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route,Routes, Switch } from 'react-router-dom';
import Login from './Component/Login';
import Info from './Component/Info';
import Home from './Component/Home';
import Order from './Component/Info';

import Cart from './Component/Salary';
import Account from './Component/Help';
import BuyPage from './Component/DocumentCenter';
import Welcome from './Component/Welcome';
import Register from './Component/Register';
import Salary from './Component/Salary';
import DocumentCenter from './Component/DocumentCenter';
import Settings from './Component/Settings';
import Help from './Component/Help';

import PFCalculator from './Component/PFCalculator.js';
import About from './Component/About';


function App() {
  return (
    <>
      <Routes>

        <Route path='/' element={<Welcome />} />
        <Route path='Register' element={<Register />} />
        <Route path='/home' element={<Home />} />
        <Route path='/info' element={<Info />} />
        <Route path='/login' element={<Login />} />
        <Route path='/salary' element={<Salary />} />
        <Route path='/documentcenter' element={<DocumentCenter />} />
        <Route path='/settings' element={<Settings />} />
        <Route path='/help' element={<Help />} />
        <Route path='/calculator' element={<PFCalculator />} />
        <Route path='/About' element={<About />} />
        
      </Routes>
     

      <div >
      </div>
    </>
  );
}

export default App;